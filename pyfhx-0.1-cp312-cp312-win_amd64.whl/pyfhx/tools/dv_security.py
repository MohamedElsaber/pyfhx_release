

if __package__.startswith("pyfhx."):
    from pyfhx.fhx import load_fhx_dir,Table,FhxObject
else:
    from ..fhx import load_fhx_dir,Table,FhxObject



# def __who_has_key(lock_name:str,obj:FhxElement):
#     lock_name="Control"
#     groups_has_lock=set()
#     for  group_has_lock in obj.xpath('GROUP.LOCK{NAME='+lock_name+'}'):
#         groups_has_lock.add(group_has_lock.parent['@NAME'))

#     users_has_lock=set()
#     for user_has_lock in obj.xpath('USER.LOCK{NAME='+lock_name+'}'):
#         users_has_lock.add(user_has_lock.parent['@NAME'))

#     for group in groups_has_lock:
#         for user_has_groups in obj.xpath('USER.GROUP{NAME='+group+'}'):
#             users_has_lock.add(user_has_groups.parent['@NAME'))        

#     return list(users_has_lock)



    # target_json="DeltaV_System"
    # json_repo_path="C:\\Users\\elsabm\\DONOTBACKUP\\DeltaV_Repos\\NPTL\\NPTL_Live\\"
    # json_dir=json_repo_path + target_json

def report_security_settings(fhx_dir):
    root=load_fhx_dir(fhx_dir,['OPERATION_SECURITY','ATTRIBUTE_SECURITY','DEFAULT_SECURITY','FIELD_SECURITY','LOCK','GROUP','USER'])
    my_tables={}

    my_tables['Security Keys']=Table('Security Keys',['Key','Scope Type'])
    for sec_locks in root.xpath('LOCK'):
        lock_name=sec_locks['@NAME']
        r=my_tables['Security Keys'].add_record()
        my_tables['Security Keys'].add_val(r,"Key",lock_name)
        my_tables['Security Keys'].add_val(r,"Scope Type",sec_locks['SCOPE_TYPE'])
        
    my_tables['Default Parameter Security']=Table('Default Parameter Security',['Key'])
    def_sec=root.getValue('DEFAULT_SECURITY/@LOCK')
    r=my_tables['Default Parameter Security'].add_record()
    my_tables['Default Parameter Security'].add_val(r,"Key",root.getValue('DEFAULT_SECURITY/@LOCK'))
    
    my_tables['Parameter Security']=Table('Parameter Security',['Parameter','Key'])
    def_sec=root.getValue('DEFAULT_SECURITY/@LOCK')
    for att_sec in root.xpath('ATTRIBUTE_SECURITY/ATTRIBUTE'):
        r=my_tables['Parameter Security'].add_record()
        my_tables['Parameter Security'].add_val(r,"Parameter",att_sec['@NAME'])
        my_tables['Parameter Security'].add_val(r,"Key",att_sec['@LOCK'])

    my_tables['Field Security']=Table('Field Security',['Field','Key'])
    for fld_sec in root.xpath('FIELD_SECURITY.FIELD'):
        r=my_tables['Field Security'].add_record()
        my_tables['Field Security'].add_val(r,"Field",fld_sec['@NAME'])
        my_tables['Field Security'].add_val(r,"Key",fld_sec['@LOCK'])

    my_tables['Function Security']=Table('Function Security',['Function','Key'])
    for op_sec in root.xpath('OPERATION_SECURITY/OPERATION'):
        r=my_tables['Function Security'].add_record()
        my_tables['Function Security'].add_val(r,"Function",op_sec['@NAME'])
        my_tables['Function Security'].add_val(r,"Key",op_sec['@LOCK'])

    my_tables['Security Groups']=Table('Security Groups',['Group Name','Description','Scope Type'])
    for sec_grp in root.xpath('GROUP'):
        r=my_tables['Security Groups'].add_record()
        my_tables['Security Groups'].add_val(r,"Group Name",sec_grp['@NAME'])
        my_tables['Security Groups'].add_val(r,"Description",sec_grp['DESCRIPTION'])
        OOB=sec_grp['@OOB']
        if OOB:
            my_tables['Security Groups'].add_val(r,"Scope Type",'Node')
        else:
            my_tables['Security Groups'].add_val(r,"Scope Type",'Area')
                    
        for l in sec_grp.xpath('LOCK'):
            my_tables['Security Groups'].add_val(r,l['NAME'],'Yes')


    my_tables['Users']=Table('Users',['NAME','FULL_NAME','DESCRIPTION','OPERATING_SYSTEM_DESCRIPTION','DOMAIN_NAME','USER_ROLE','CERTIFICATE'])
    my_tables['Users Keys+Inherited Group Keys']=Table('Users Keys+Inherited Group Keys',['NAME'])
    for usr in root.xpath('USER'):
        u_name=usr['@NAME']
        r=my_tables['Users'].add_record()
        my_tables['Users'].add_val(r,'NAME',u_name)

        r_user_keys=my_tables['Users Keys+Inherited Group Keys'].add_record()
        my_tables['Users Keys+Inherited Group Keys'].add_val(r_user_keys,'NAME',u_name)
        my_tables['Users Keys+Inherited Group Keys'].add_val(r_user_keys,'FULL_NAME',usr['FULL_NAME'])
        for p in usr:
            if p in ['__fhx_type','@OOB','@NAME','@user','@time']:
                pass
            else:
                p_val=usr[p]
                if isinstance(p_val,str):
                    if p_val=='T':
                        p_val='Yes'
                    elif p_val=='F':
                        p_val=''

                    my_tables['Users'].add_val(r,p,p_val)
                else:
                    pass

        for l in usr.xpath('LOCK'):
            my_tables['Users'].add_val(r,'Key: ' + l['NAME'],'Yes')
            my_tables['Users Keys+Inherited Group Keys'].add_val(r_user_keys,l['NAME'],'Yes')

        for g in usr.xpath('GROUP'):
            g_name=g['NAME']
            my_tables['Users'].add_val(r,'Group: ' +g_name,'Yes')

            for lock in root.xpath('GROUP{@NAME='+ g_name +'}.LOCK'):
                my_tables['Users Keys+Inherited Group Keys'].add_val(r_user_keys,lock['NAME'],'Yes')

    return my_tables