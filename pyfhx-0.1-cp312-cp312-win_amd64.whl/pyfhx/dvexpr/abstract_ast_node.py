from __future__ import annotations
class AbstractASTNode(dict):
    def __init__(self) -> None:
        self['line']=0
        self['column']=0