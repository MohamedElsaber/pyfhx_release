from .abstract_ast_node import AbstractASTNode

class FunctionCall(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['name']=None
        self['arguments']=[]

    def __str__(self)-> str:
        argument=""
        for arg in self['arguments']:
            argument += str(arg) + ", "

        return f"{self['name']}({argument[:-2]})"

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'


class FunctionDefinition(AbstractASTNode):
    name=None
    def __init__(self) -> None:
        super().__init__()
        self['name']=None

    def __str__(self)-> str:
        return str(self['name'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'
