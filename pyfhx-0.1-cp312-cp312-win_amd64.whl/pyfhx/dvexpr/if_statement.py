from .abstract_ast_node import AbstractASTNode

class IfStatement(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['condition']=None
        self['ifStatements']=None
        self['elseStatements']=None
    
    def __str__(self)-> str:
        if self['elseStatements']:
            return "If " + str(self['condition'])+ " Then\n" + str(self['ifStatements']) +"Else\n" +str(self['elseStatements'])+ "EndIf\n"
        else:
            return "If " + str(self['condition'])+ " Then\n" + str(self['ifStatements']) + "EndIf\n"

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'