from __future__ import annotations
from .abstract_ast_node import AbstractASTNode

class DVExpression(AbstractASTNode):
    def __init__(self) -> None:        
        super().__init__()
        self['details']=''
        self['type']=''
        self['statements']=[]
        self['comments']=[]
        self['errors']=[]

    def __str__(self)-> str:
        out=str(self['statements'])
        return out

    def has_errors(self)-> bool:
        return len(self['errors'])>0
    
    def get_errors(self)->str:
        if self.has_errors():
            out=self['details'] + f' {self['type']} errors:\n'
            for s in self['errors']:
                out += f'\t{s}\n'

            return out
        return ''

    def __repr__(self) -> str:
         if self.has_errors():             
             return f'{self.__class__.__name__}:errors- {str(self['statements'])}' 
          
         return f'{self.__class__.__name__}:{self.__str__()}'  
    
class StatementsScope(list):
    def __init__(self) -> None:        
        super().__init__()

    def __str__(self)-> str:
        out=""
        for i in self:
            out+= str(i) + '\n'

        return out

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}:{self.__str__()}'  