from .abstract_ast_node import AbstractASTNode

class BinaryExpression(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['operator']=None
        self['left_hand']=None
        self['right_hand']=None
        self['operator_type']=None

    def __str__(self)-> str:
        return str(self['left_hand']) + " " + str(self['operator']) + " " +  str(self['right_hand'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'


