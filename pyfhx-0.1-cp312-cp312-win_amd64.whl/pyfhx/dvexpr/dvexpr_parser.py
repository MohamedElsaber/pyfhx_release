import logging
from . import pyfhx_c
from .abstract_ast_node import AbstractASTNode
from .assignment import Assignment,Comment
from .binary_expression import BinaryExpression
from .unary_expression import UnaryExpression
from .if_statement import IfStatement
from .condition_expression import ConditionalExpression
from .while_statement import WhileStatement
from .function_expr import FunctionCall,FunctionDefinition
from .expr_statement import ExprStatement
from .expr_parenthesis import ExprParenthesis
from .command_statement import CommandStatement
from .parameter import Parameter, IndexExpression,Constant
from .parameter import VariablesDefinition
from .scope import DVExpression,StatementsScope

from typing import List

dv_expr_classes=   {
                    "Assignment":Assignment,
                    "BinaryExpression": BinaryExpression,
                    "UnaryExpression": UnaryExpression,
                    "IfStatement": IfStatement,
                    "ConditionalExpression": ConditionalExpression,
                    "WhileStatement": WhileStatement,
                    "FunctionCall": FunctionCall,
#                    "FunctionDefinition":FunctionDefinition,
                    "ExprParenthesis":ExprParenthesis,
                    "ExprStatement": ExprStatement,
                    "CommandStatement": CommandStatement,
                    "Parameter": Parameter,
                    "IndexExpression": IndexExpression,
                    "VariablesDefinition":VariablesDefinition,
                    "StatementsScope":StatementsScope,
                    "Comment":Comment,
                    "Constant":Constant,
                    "DVExpression":DVExpression
                    }


def set_ExprClasses():
    """Set Abstract Syntax Tree Classes Class to be instanciated"""
    return pyfhx_c.set_DVExprClasses(dv_expr_classes)

def parseExpression(expr:str,details:str='')-> DVExpression:
    """Parse a DeltaV expression and return the AST as a dictionary"""
    if expr != None:
        obj:DVExpression=pyfhx_c.parseDVExpr(expr + ';')
        if (obj):
            obj['type']='parseExpression'
            obj['details']=details
            if obj.has_errors():
                logging.error(f'parseExpression {obj.get_errors()}')
        return obj

def parseAction(expr:str,details:str='')-> DVExpression:
    """Parse a DeltaV expression and return the AST as a dictionary"""
    if expr != None:
        obj:DVExpression=pyfhx_c.parseAction(expr + ';')
        if (obj):
            obj['type']='parseAction'
            obj['details']=details
            if obj.has_errors():
                logging.error(f'{obj.get_errors()}')
        return obj


def parseCondition(expr:str,details:str='')-> DVExpression:
    """Parse a DeltaV expression and return the AST as a dictionary"""
    if expr != None:
        obj:DVExpression=pyfhx_c.parseCondition(expr +';')
        if (obj):
            obj['type']='parseCondition'
            obj['details']=details
            if obj.has_errors():
                logging.error(f'{obj.get_errors()}')
        return obj

setClasses=set_ExprClasses()
