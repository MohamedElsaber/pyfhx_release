from .abstract_ast_node import AbstractASTNode

class CommandStatement(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['command']=None

    def __str__(self)-> str:
        return str(self['command'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'
