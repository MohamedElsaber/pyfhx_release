from .abstract_ast_node import AbstractASTNode

class ConditionalExpression(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['condition']=None
        self['expr_if_true']=None
        self['expr_if_false']=None

    def __str__(self)-> str:
        return str(self['condition']) + " ? " + str(self['expr_if_true']) + ":"+ str(self['expr_if_false'] )

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'