from .abstract_ast_node import AbstractASTNode

class UnaryExpression(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['operator']=None
        self['expression']=None
        self['operator_type']=None

    def __str__(self)-> str:
        return str(self['operator']) +  str(self['expression'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'  

