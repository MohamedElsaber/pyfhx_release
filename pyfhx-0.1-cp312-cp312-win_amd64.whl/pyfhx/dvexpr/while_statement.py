from .abstract_ast_node import AbstractASTNode

class WhileStatement(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['condition']=None
        self['statements']=None

    def __str__(self)-> str:
        return "While " + str(self['condition']) + "\nDO\n" + str(self['statements']) + "END_WHILE"

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'

            