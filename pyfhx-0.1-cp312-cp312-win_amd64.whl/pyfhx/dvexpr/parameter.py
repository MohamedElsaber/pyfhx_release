from __future__ import annotations
from .abstract_ast_node import AbstractASTNode


class VariablesDefinition(AbstractASTNode):
    def __init__(self) -> None:        
        super().__init__()
        self['variables']=[]

    def __str__(self)-> str:
        out="VAR\n"
        for i in self['variables']:
            out+= '  ' +str(i) + '\n'

        return out + "END_VAR"

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'
    
class Parameter(AbstractASTNode):
    """
      @type: DVPARAM or (ID i.e internal variable)
      @parameter: paramater from the deltav expression
    # @array: if @paramater in the format of 'XXXXX[5].CV' 
    # @array this would be 'XXXXX.CV' and the object will be in an IndexedExpression 
    # object and 5 will be the index expression
    # """
    def __init__(self) -> None:        
        super().__init__()
        self['parameter']=None
        self['type']=None
        self['array']=None 

    def __str__(self)-> str:
        return str(self['parameter'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'

class IndexExpression(AbstractASTNode):
    def __init__(self) -> None:        
        super().__init__()
        self['array']=None
        self['index']=None # for array access

    def __str__(self)-> str:
        return f'{str(self['array'])}[{str(self['index'])}]'

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'
    

class Constant(AbstractASTNode):
    def __init__(self) -> None:        
        super().__init__()
        self['constant']=None
        self['type']=None

    def __str__(self)-> str:
        return str(self['constant'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'