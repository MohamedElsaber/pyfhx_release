from .abstract_ast_node import AbstractASTNode

class Assignment(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['left_hand']=None
        self['right_hand']=None

    def __str__(self)-> str:
        return str(self['left_hand']) + " := " +  str(self['right_hand'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'
    
class Comment(AbstractASTNode):
    def __init__(self) -> None:
        super().__init__()
        self['comment']=None
        self['type']=None

    def __str__(self)-> str:
        return str(self['comment'])

    def __repr__(self) -> str:
         return f'{self.__class__.__name__}: {self.__str__()}'
