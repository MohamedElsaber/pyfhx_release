
from .fhx_object import FhxObject
class Table:
    """table class"""
    ############################
    ## method 
    #      
    def __init__(self,title,initial_cols=[],na_value='') -> None:
        self.title=title
        self.header={}
        if isinstance(initial_cols,list):
            for col in initial_cols:
                self.header[col]=len(self.header)
            
        self.na_value=na_value        
        self.records=[]
        self.next_parent_col=0

    ############################
    ## method 
    #  
    def get_columns(self):
        """ get list of columns in the correct sequence"""
        return sorted(self.header, key=lambda k: self.header[k])

    ############################
    ## method 
    #  
    def insert_parent_column(self,col):
        """Insert a parent identification column"""
        for c in self.header:
            if self.header[c]>=self.next_parent_col:
                self.header[c]=self.header[c]+1

        self.header[col]= self.next_parent_col

        for r in self.records:
            r.insert(self.next_parent_col,self.na_value)

        self.next_parent_col=self.next_parent_col+1
    ############################
    ## method 
    #  
    def add_val(self,record,col,val):
        """add value to the recod, if the field does not exist, it add the field and fill other records with na value"""
        if not(col in self.header):
            if ('.' in col):
                if self.title=='VALUE' and len(self.header)>4:
                    self.title='VALUE'   

                self.insert_parent_column(col)
            else:
                self.header[col]=len(self.header)
                for r in self.records:
                    r.append(self.na_value)

        index=self.header[col]
        record[index]=val

    ############################
    ## method 
    #  
    def add_record(self):
        record=[]
        for col in self.header:
            record.append(self.na_value)

        self.records.append(record)
        return record

    ############################
    ## method 
    #      
    def does_header_match(self,table):
        for field in self.header:
            if field in table.header:
                if self.header[field]==table.header[field]:
                    pass
                else:
                    return False
        return True
    
    ############################
    ## method to add tables
    #  
    def combine_table(self,table):
        try:
            if self.does_header_match(table):
                self.records+=table.records
            else:
                for r in table.records:
                    self_r=self.add_record()
                    for f in table.header:
                        f_index=table.header[f]
                        self.add_val(self_r,f,r[f_index])

        except Exception as e:
            print("combine_table faild: "+ str(e))

#######################################################
#
#
#
def add_parent_id(fhxobj:FhxObject,table:Table,record):
    """add parent identifications"""
    if fhxobj==None:
        return
    
    if fhxobj.parent==None:
        return
    
    add_parent_id(fhxobj.parent,table,record)
    
    tag,my_id=fhxobj.get_id()

    table.add_val(record,tag,my_id)

    # my_xpath=fhxobj.my_xpath()
    # table.add_val(record,'#PARENT_XPATH',my_xpath)     

#######################################################
#
#
#
def toTables(fhxObj_or_List,tables={},exclude=[]) -> dict:
    """converts fhx object or list of fhx objects to tables"""
    
    if not(isinstance(tables,dict)):
        tables={}

    if isinstance(fhxObj_or_List,list):
        for list_item in fhxObj_or_List:
            if isinstance(list_item,FhxObject):
                tables=toTables(list_item, tables, exclude)     
        return tables
      
    if not(isinstance(fhxObj_or_List,FhxObject)):
        return tables
    
    fhxobj:FhxObject=fhxObj_or_List
    if not (fhxobj.fhx_type in tables):
        tables[fhxobj.fhx_type]=Table(fhxobj.fhx_type,initial_cols=[])

    table=tables[fhxobj.fhx_type]

    record=table.add_record()

    add_parent_id(fhxobj.parent,table,record)

    if not (isinstance(exclude,list)):
        exclude=[]

    if not('âfhx_type' in exclude):
        exclude.append('âfhx_type')

    #scan string fields
    for field in fhxobj:
        if (field in exclude):
            pass
        elif isinstance(fhxobj[field],str):
            field_value=fhxobj.getValue(field)
            table.add_val(record, field , field_value)   

    #scan list fields
    for field in fhxobj:
        if (field in exclude):
            pass 
                                  
        elif isinstance(fhxobj[field],list):
            for list_item in fhxobj[field]:
                if isinstance(list_item,FhxObject):
                    tables=toTables(list_item, tables, exclude)            
    return tables

# def Tables2Excel(fhxObj_tables,excel_file:str):
#     """Export an FHX object or list of objects to Excel file"""

#     writer = pd.ExcelWriter(excel_file,engine='xlsxwriter')
#     try:
#         for fhxObj_table in fhxObj_tables.values():
#             tx= pd.DataFrame(fhxObj_table.records,columns=fhxObj_table.get_columns())        
#             tx.to_excel(writer,sheet_name=fhxObj_table.title,index=False)       
#         writer.close() 
#     except Exception as e:
#         print (e)

# def Table2Excel(fhxObj_table,excel_file:str):
#     """Export an FHX object or list of objects to Excel file"""

#     writer = pd.ExcelWriter(excel_file,engine='xlsxwriter')
#     try:
#         tx= pd.DataFrame(fhxObj_table.records,columns=fhxObj_table.get_columns())        
#         tx.to_excel(writer,sheet_name=fhxObj_table.title,index=False)       
#         writer.close() 
#     except Exception as e:
#         print (e)

# #############################
# #
# #
# def fromTabels(tables:dict)-> FhxObject:
#     """ return list of FHX objects from tables"""
#     #TODO
#     pass