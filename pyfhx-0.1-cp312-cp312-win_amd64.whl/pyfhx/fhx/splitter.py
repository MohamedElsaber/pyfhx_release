import logging
import os
import shutil
import json
import re
from .fhx_object import FhxObject
from .fhx_parser import FhxFileParser
from .config import elements_config

logging.basicConfig(
    level=logging.DEBUG,
    format="%(levelname)s - %(message)s"
)

fhx_object_type_count={}
function_block_definitions={}
file_order={}
file_handler={}
EquipmentModuleClasses=set()
json_collection_files=set()
gKeep_string_quot=1
##############
## Method
############## 
def __save_fhx(obj,path):
    if obj.fhx_file is None or len(obj.fhx_file) < 5:
        logging.error(f'Element type {obj.fhx_type}: improper .fhx file: {obj.fhx_file}')
        
    obj.fhx_file =obj.fhx_file + '.fhx'
    filename=path+obj.fhx_file
    if(os.path.isfile(filename)):
        with open(filename, 'a', newline='', encoding='utf-8') as file:
            file.write(obj.to_fhx())

    else:
        os.makedirs(os.path.dirname(filename), exist_ok = True)
        with open(filename, 'w', newline='', encoding='utf-8') as file:
            file.write(obj.to_fhx())


    
##############
## Method
############## 
def __save_json(obj,path):
    if obj.fhx_file is None or len(obj.fhx_file) < 5:
        logging.error(f'Element type {obj.fhx_type}: improper .json file: {obj.fhx_file}')
    
    obj.fhx_file =obj.fhx_file + '.json'
    filename=path+obj.fhx_file 
    toPrint=json.dumps({'__fhx_type': obj.fhx_type, **obj},indent=2)
    if(os.path.isfile(filename)):
        if not filename in json_collection_files:
            json_collection_files.add(filename)   
            with open(filename, "r", encoding="utf-8") as file:
                original_content = file.read()

            with open(filename, 'w', newline='', encoding='utf-8') as file:
                file.write(f'[\n{original_content}') 
                file.write(f',\n{toPrint}')                 
        else:
            with open(filename, 'a', newline='', encoding='utf-8') as file:
                file.write(f',\n{toPrint}') 
    else:
        os.makedirs(os.path.dirname(filename), exist_ok = True)
        with open(filename, 'w', newline='', encoding='utf-8') as file:
            file.write(toPrint) 

##############
## Method
##############                         
def __close_json_collection_files():
    for filename in json_collection_files:
        with open(filename, 'a', newline='', encoding='utf-8') as file:
            file.write(f'\n]\n') 

##############
## Method
##############  
def IsEMC(elem:FhxObject):
    if elem.fhx_type=='MODULE_CLASS':
        if (elem.getValue('FBD_ALGORITHM/IS_EQUIPMENT_MODULE') == 'T'):
            EquipmentModuleClasses.add(elem['@NAME'])
            return True
        if (elem.getValue('COMMAND_DRIVEN_ALGORITHM/IS_EQUIPMENT_MODULE') == 'T'):
            EquipmentModuleClasses.add(elem['@NAME'])
            return True

    return False

##############
## Method
############## 
def IsEMI(elem):
    mcname=elem['@MODULE_CLASS']
    return mcname in EquipmentModuleClasses

##############
## Method
############## 
def add_quotes(value):
    if gKeep_string_quot:
        return f'"{value}"'
    else:
        return value
##############
## Method
############## 
def file_details(elm,file_order):
    if elm.fhx_type=='MODULE_CLASS':
        if IsEMC(elm):
            d= elm.fhx_file+ ',EMC'
        else:
            d= elm.fhx_file+ ',CMC'

    elif elm.fhx_type=='MODULE_INSTANCE':
        if IsEMI(elm):
            d= elm.fhx_file+ ',EMI'
        else:
            d= elm.fhx_file+ ',CMI'

    elif elm.fhx_type =='BATCH_RECIPE':
        d= elm.fhx_file+ ',' + elm['@TYPE']

    elif elm.fhx_type =='FUNCTION_BLOCK_DEFINITION':
        cat=elm['@CATEGORY']
        if cat=='':
            d= elm.fhx_file+ ',Embedded'
        else:
            d= elm.fhx_file+ ',Linked'

    elif elm.fhx_type in elements_config:
        d= elm.fhx_file
    else:
        file_order[elm.fhx_type]= elm.fhx_file
        return file_order
    
    if elm.fhx_type in file_order:
        file_order[elm.fhx_type].append(d)
    else:
        file_order[elm.fhx_type]= [d]    

    return file_order
    

##############
## Method
##############     
def __tokenReplace(obj, text:str):
    '''Replaces all {{token}} values in provided text with value from obj, much like Jinja2 tokens are instantiated'''
    out=""
    if '|' in text:
        for  option in text.split("|"):
            out=__tokenReplace_option(obj,option)
            if len(out)>0:# return the first option that contain all resolved tokens
                return out.replace('.','').replace('>','')
    else:
        out= __tokenReplace_option(obj,text)
    
    if len(out)==0:
        print('Warning: Object of a type (' + obj.fhx_type + ') did not resolve tokens ' + text)
        try:
            print('Object: ' + obj.to_fhx()[:100].replace('\r\n',' '))
        except:
            pass
    
        return ''

    return out
    
##############
## Method
##############     
def __tokenReplace_option(obj:FhxObject, text:str):
    tokens = re.findall('({{.+?}})', text)
    for t in tokens:
        temp = t.replace('{{', '').replace('}}', '')
        rep=obj.getValue(temp)
        if isinstance(rep,str):
            if rep=='':
                return ''

            rep = re.sub(r'[\.\|\$\\><\?\:\"\* ]', '', rep)
            text = text.replace(t, rep)
        else:
           return ''        
    return text


##############
## Method
##############  
def __assign_file_name(obj:FhxObject):   
    global file_handler 
    if obj.fhx_type in elements_config:
        dir_tokens=elements_config[obj.fhx_type]['dir']
        file_tokens=elements_config[obj.fhx_type]['file_name']
        try:
            obj_dir=__tokenReplace(obj,dir_tokens)
            if obj_dir=='':
                obj_dir=elements_config['Xtra'] + '/' + obj.fhx_type

            obj_file=__tokenReplace(obj,file_tokens)
            if obj_file=='':
                obj_file=obj.fhx_type

            if obj.fhx_type in elements_config['AdvancedDefinitions']:
                if obj_dir.startswith('/Library/'):
                    obj_dir='/Library/Advanced Definitions/' +  obj_dir[9:] 

            return obj_dir + '/' +obj_file
        except Exception as er:              
            print (er)
    else:
        return elements_config['Xtra'] + '/' + obj.fhx_type
   
##############
## Method
############## 
def delete_except_dot_folders(out_path):
    for dir_file in os.listdir(out_path):
        # Remove files that do not start with a dot
        if not dir_file.startswith('.'):
            fd= os.path.join(out_path, dir_file)
            try:
                if os.path.isfile(fd):
                    os.remove(fd)
                else:
                    shutil.rmtree(fd)
            except Exception as e:
                logging.warning(f'Deleting : {fd} error msg {str(e.strerror)}')

##############
## Method
############## 
def split(fhx_file, out_path,keep_string_quot=1,delete_path=True) : 
    """Split large FHX file to separate file, each file has a sing FHX element"""
    global gKeep_string_quot
    
    if delete_path and os.path.exists(out_path) :
        logging.info(f'Deleting existing fhx path: {out_path}')
        try:
            delete_except_dot_folders(out_path) 
        except Exception as e:
            logging.error(f'Deleting existing fhx path: {out_path} error msg {str(e.strerror)}')

    logging.info(f'Splitting the FHX file ({fhx_file}) to fhx files')

    # logic_objects=["MODULE_CLASS",
    #          "MODULE_INSTANCE",
    #          "MODULE",
    #          "FUNCTION_BLOCK_DEFINITION",
    #          "BATCH_EQUIPMENT_PHASE_CLASS"]
    logic_objects=elements_config['logicFhxTypes']
    gKeep_string_quot=keep_string_quot
    fhxParser=FhxFileParser(fhx_file,keep_string_quot)
    fbd_users={}  
    multi_obj_files=set()  
    # save files 
    file_order={}
    root=FhxObject(fhx_type='root')

    #element = fhxParser.nextFhxObject()
    for element in fhxParser:
    #while element is not None:
        if element.fhx_type in elements_config["Ignore"]:
            pass
        elif isinstance(element , FhxObject): 
            filename=__assign_file_name(element)        
            element.fhx_file=filename 
                    
            __save_fhx(element,out_path)
            if(element.fhx_type in logic_objects):
                root.add_child(element)
                fbd_users=__update_fbd_users(element,fbd_users)   
                if not (element.fhx_type in file_order):
                    file_order[element.fhx_type]= []  
            else:
                if element.fhx_file in multi_obj_files:
                    pass
                else:
                    multi_obj_files.add(element.fhx_file)
                    file_order=file_details(element,file_order)
        else:
            logging.error(f'{str(element)} can only be a FhxObject') 

        #try:
        #    element = fhxParser.nextFhxObject() 
        #except Exception as e:
        #    logging.error(f'Error reading element last element ended at offeset {str(element.fhx_ends)} : {str(e)}')
                                 

    __move_Function_Block_Definition_files(out_path,fbd_users)

    __move_module_instances(root,out_path)

    __clean_up(out_path)

    __update_order_file(root,file_order,out_path)


##############
## Method
############## 
def split_json(fhx_file, out_path,keep_string_quot=1,delete_path=True) : 
    """Split large FHX file to separate file, each file has a sing FHX element"""
    global gKeep_string_quot
    
    if delete_path and os.path.exists(out_path) :
        logging.info(f'Deleting existing fhx path: {out_path}')
        try:
            delete_except_dot_folders(out_path) 
        except Exception as e:
            logging.error(f'Deleting existing fhx path: {out_path} error msg {str(e.strerror)}')

    logging.info(f'Splitting the FHX file ({fhx_file}) to json files')

    logic_objects=["MODULE_CLASS",
             "MODULE_INSTANCE",
             "MODULE",
             "FUNCTION_BLOCK_DEFINITION",
             "BATCH_EQUIPMENT_PHASE_CLASS"]

    gKeep_string_quot=keep_string_quot
  
    fhxParser=FhxFileParser(fhx_file,keep_string_quot)
    fbd_users={}  
    multi_obj_files=set()  
    # save files 
    file_order={}
    root=FhxObject(fhx_type="root")

    element = fhxParser.nextFhxObject()

    while element is not None:
        if element.fhx_type in elements_config["Ignore"]:
            pass
        elif isinstance(element , FhxObject): 
            filename=__assign_file_name(element)        
            element.fhx_file=filename
            
            __save_json(element,out_path)
            if(element.fhx_type in logic_objects):
                root.add_child(element)
                fbd_users=__update_fbd_users(element,fbd_users)   
                if not (element.fhx_type in file_order):
                    file_order[element.fhx_type]= []  
            else:
                if element.fhx_file in multi_obj_files:
                    pass
                else:
                    multi_obj_files.add(element.fhx_file)
                    file_order=file_details(element,file_order)
        else:
            logging.error(f'{str(element)} can only be a a FhxObject') 

        try:
            element = fhxParser.nextFhxObject() 
        except Exception as e:
            logging.error(f'Error reading element last element ended at offeset {str(element.fhx_ends)} : {str(e)}')
                                 

    __move_Function_Block_Definition_files(out_path,fbd_users)

    __move_module_instances(root,out_path)

    __close_json_collection_files()

    __clean_up(out_path)

    __update_order_file(root,file_order,out_path)



####
## function
#####
def __update_order_file(fhx_obj:FhxObject,file_order:dict,fhx_path):
    
    for element in fhx_obj.values():
        if isinstance(element,str):
            continue
        elif isinstance(element , list):
            for e in element:
                file_order=file_details(e,file_order)     

    order_filename=fhx_path+'/fhx_objects_order.json'

    with open (order_filename,mode='w',encoding='utf-8') as f:
        json.dump(file_order,f,indent=2)



####
## function
#####
def __move_Function_Block_Definition_files(path,fbd_users):
    moved_fbds=[]

    for fbd in fbd_users.keys():
        this_fbd_users=fbd_users[fbd]
        
        if len (this_fbd_users)==0:
            continue

        first_user=this_fbd_users[0]
        this_fbd=first_user.getRoot().getValue('FUNCTION_BLOCK_DEFINITION/{@NAME=' + add_quotes(fbd) + '}')
        if this_fbd==None:
            logging.error("root.xpath(FUNCTION_BLOCK_DEFINITION/{@NAME=" + fbd + "})")
            raise LookupError("root.xpath(FUNCTION_BLOCK_DEFINITION/{@NAME=" + add_quotes(fbd) + "})")
        
        first_user_file=first_user.get_file_name()
        if first_user_file.startswith(elements_config['Xtra']):
            continue

        current_file=this_fbd.get_file_name()
        filename, file_extension = os.path.splitext(current_file)
        if __isFbd_Using_Embedded(this_fbd):
            newdir=os.path.dirname(first_user_file)+'/' + first_user['@NAME']+'/'
        else:
            newdir=os.path.dirname(first_user_file)+'/'
        
        newfile=newdir+first_user['@NAME']+file_extension

        os.makedirs(os.path.dirname(path+newfile), exist_ok = True)   
        shutil.move(path+ current_file,path + newfile )
        this_fbd.fhx_file = newfile
        moved_fbds.append(fbd) 
        if len(this_fbd_users)>1:
            pass ##TODO #
            
    if len(moved_fbds)>0:
        for fbd in moved_fbds:
            fbd_users.pop(fbd)   

        __move_Function_Block_Definition_files(path,fbd_users)

    return

####
## function
#####
def __clean_up(path):
    # remove FUNCTION_BLOCK_DEFINITION folder if empty
    fbd_path=path+ '/' +elements_config['Xtra'] + '/FUNCTION_BLOCK_DEFINITION'
    if (os.path.isdir(fbd_path)):
        ls=os.listdir(fbd_path)
        if len(ls)==0:
            try:
                shutil.rmtree(fbd_path) 
            except Exception as e:
                pass

####
## function
#####
def __isFbd_Using_Embedded(fbd):
    if hasattr(fbd,'uses_fbds'):
        return fbd.uses_fbds
    else:
        return False
####
## function
#####
def __update_fbd_users(element,fbd_users):
    if element.fhx_type=='MODULE_CLASS':
        fbs=element.xpath('FUNCTION_BLOCK')               
    elif element.fhx_type=='FUNCTION_BLOCK_DEFINITION':
        fbs=element.xpath('FUNCTION_BLOCK')             
    elif element.fhx_type=='BATCH_EQUIPMENT_PHASE_CLASS':
        fbs=element.xpath('PHASE_CLASS_ALGORITHM/FUNCTION_BLOCK')  
    elif element.fhx_type=='MODULE':
        fbs=element.xpath('FUNCTION_BLOCK')                            
    else:
        return fbd_users

    for fb in fbs:
        defn=fb['@DEFINITION']
        if defn.startswith('__') and defn.endswith('__'):
            if element.fhx_type=='FUNCTION_BLOCK_DEFINITION':
                element.uses_fbds=True

            if not(defn in fbd_users):
                fbd_users[defn]=[]            
            fbd_users[defn].append(fb)                

    return fbd_users
####
## function
#####
def __move_module_instances(root,path):
    for mi in root.xpath('MODULE_INSTANCE'):
        block_resolution=mi.xpath('MODULE_BLOCK_RESOLUTION')
        if len(block_resolution)>0:
            # moving the main em file to a folder for its name
            current_file=mi.get_file_name()
            filename, file_extension = os.path.splitext(current_file)            
            newdir=os.path.dirname(current_file)+'/' +mi['@TAG']+'/'
            newfile=newdir+mi['@TAG']+file_extension
            os.makedirs(os.path.dirname(path+newfile), exist_ok = True)   
            shutil.move(path+ current_file,path + newfile )
            mi.fhx_file = newfile        

            mc_name=mi['@MODULE_CLASS']
            mc=root.getValue('MODULE_CLASS/{@NAME=' + add_quotes(mc_name) + '}')
            owned_modules=mc.getValue('MODULE_BLOCK/{OWNERSHIP=OWNED}/@NAME')
            owned_modules=list(map(lambda x: x.strip('"'), owned_modules))
            # move subordinate private module instance
            for br in block_resolution:
                mr_module=br['MODULE']                
                if mr_module =='':
                    pass
                else:
                    mr_name=br['@NAME']
                    if mr_name in owned_modules:
                        #move the file
                        owned_mi=root.getValue('MODULE_INSTANCE/{@TAG=' + add_quotes(mr_module) + '}')

                        current_file=owned_mi.get_file_name()
                        filename, file_extension = os.path.splitext(current_file)  
                        newdir=os.path.dirname(mi.fhx_file)+'/'
                        newfile=newdir+mr_module+file_extension
                        os.makedirs(os.path.dirname(path+newfile), exist_ok = True)   
                        shutil.move(path+ current_file,path + newfile )
                        owned_mi.fhx_file = newfile   
