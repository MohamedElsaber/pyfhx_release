"""General utility functions for hte FHX module"""
import json
import os
import logging

def _is_quoted(v: str) -> bool:
    return v.startswith('"') and v.endswith('"')


def _add_quotes(old_value: str, new_value: str) -> str:
    """Add encapsulating double quotes to new_text if old_text had them: '"string"' -> 'string'.
    Returns value if not a string"""
    if isinstance(old_value,str):
        if _is_quoted(old_value):
            new_value = '"' + new_value + '"'
    return new_value


def _remove_quotes(value: str) -> str:
    """Remove encapsulating double quotes: '"string"' -> 'string'.
    Returns value if not a string"""
    if isinstance(value,str):
        if _is_quoted(value):
            value = value[1:-1].strip()

    return value

##############
## Method
############## 
def add_quotes(value,add_quot):
    if add_quot:
        return f'"{value}"'
    else:
        return value

def _save_dict(filename: str, dict_var: dict) -> None:
    """Save dict as JSON, creating directory if it doesn't exist"""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w', newline='\n', encoding='utf-8') as file:
        json.dump(dict_var, file, indent=2)
        file.write('\n')  # Add newline because Py JSON does not

def _save_fhx(filename: str, fhx: str) -> None:
    """Save dict as JSON, creating directory if it doesn't exist"""
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w', newline='\n', encoding='utf-8') as file:
        file.write(fhx)
