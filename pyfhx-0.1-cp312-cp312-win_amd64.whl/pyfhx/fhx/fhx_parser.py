from __future__ import annotations
import os
from .fhx_object import FhxObject
from . import pyfhx_c

setClasses=pyfhx_c.set_FhxClass(FhxObject)

def load_license(license_file:str):
    """Load a license file and validate it against the provided hardware ID"""
    return pyfhx_c.load_license(license_file)

def get_hardware_id():
    """Get the hardware ID"""
    return pyfhx_c.get_hardware_id()

def get_license_info():
    """Get license information from the currently loaded license file"""
    return pyfhx_c.get_license_info()

def set_FhxClass(fhx_class):
    """Set the FhxObject Class to be instanciated. argument: fhx_class"""
    return pyfhx_c.set_FhxClass(fhx_class)


def loads(fhx_string:str)-> FhxObject:
    """Load the string into list of objects. arguemnts string"""
    return pyfhx_c.loads(fhx_string)


class FhxFileParser():
    parser=None
    filename=''
    def __init__(self,filename:str='',keep_string_quotes:bool=True,ignore_invalid_characters:bool=True):
        if filename and os.path.isfile(filename):
            self.filename=filename
            self.parser=pyfhx_c.FhxFileParser(filename, keep_string_quotes, ignore_invalid_characters)
        else:
            raise FileNotFoundError(f"File {filename} not found.")
        
    def nextFhxObject(self)->FhxObject:
        """Get the next object from the parser"""
        if (self.parser!=None):
            return self.parser.nextFhxObject()
        else:
            return None

    def getNumOfParsedObjects(self)->int:
        """Get the Number Of Parsed Objects"""
        if (self.parser!=None):
            return self.parser.getNumOfParsedObjects()
        else:
            return 0
    
    def __iter__(self):
        if (self.parser!=None):
            return self.parser.__iter__()
        return self.__iter__()

