from __future__ import annotations
import os
from . import pyfhx_c
from .utils import _add_quotes, _remove_quotes, _save_fhx

def xpath(obj:FhxObject,xpath_string:str)-> list:
    """Performs an XPath-like query on a nested Python structure.
    This is the main entry point. It traverses the 'data' object based on 'query'.
    If the result is a single object, it is wrapped in a list. If multiple objects
    match, a list is returned.
    @param obj The root FhxObject to search.
    @param query The forward-slash delimited path string e.g FUNCTION_BLOCK_DEFINITION{@NAME=val}/FUNCTION_BLOCK{@DEFINITION=def}/@NAME.
           when true: FUNCTION_BLOCK_DEFINITION{@NAME~regex_pattern1;@CATEGORY!=""}/FUNCTION_BLOCK{@DEFINITION~regex_pattern2}/@NAME.
    @return A list of matching FhxObject instances or string values.
  """
    xpath_query=pyfhx_c.xpath(obj, xpath_string)
    return xpath_query['results'] if xpath_query else []

def parse_xpath_query(xpath_string:str)-> list:
    """Performs an XPath-like query on a nested Python structure.
    This is the main entry point. It traverses the 'data' object based on 'query'.
    If the result is a single object, it is wrapped in a list. If multiple objects
    match, a list is returned.
    @param obj The root FhxObject to search.
    @param query The forward-slash delimited path string e.g FUNCTION_BLOCK_DEFINITION{@NAME=val}/FUNCTION_BLOCK{@DEFINITION=def}/@NAME.
           when true: FUNCTION_BLOCK_DEFINITION{@NAME~regex_pattern1;@CATEGORY!=""}/FUNCTION_BLOCK{@DEFINITION~regex_pattern2}/@NAME.
    @return A list of matching FhxObject instances or string values.
  """
    parsed_xpath_query=pyfhx_c.parse_xpath_query(xpath_string)
    return parsed_xpath_query

def to_fhx(obj:FhxObject,quotes_on:bool=False)-> str:
    """Generate UTF8 text of FHX. arguments: obj, quotes_on=False"""
    return pyfhx_c.to_fhx(obj,quotes_on)




################
#
################
class FhxObject(dict):
    fhx_type = None
    parent:FhxObject = None
    fhx_begins=0
    fhx_ends=0
    fhx_file=None
    
################
#
################    
    def __init__(self,obj_dict=None,fhx_type=None,fhx_begins=0,fhx_ends=0,fhx_file=None):
        self.fhx_type=fhx_type 
        self.fhx_begins=fhx_begins
        self.fhx_ends=fhx_ends  
        self.fhx_file=fhx_file        
        if isinstance(obj_dict,dict):
            self.load_dict(obj_dict)

    #############
    # method
    ############
    def load_dict(self,obj_dict):
        for k,v in obj_dict.items():
            if isinstance(v,list):
                for item in v:
                    self.add_child(FhxObject(item,fhx_type=k))
            elif isinstance(v,dict):
                self.add_child(FhxObject(v,fhx_type=k))
            elif isinstance(v,str):
                self[k]=v      


 ################
#
################    
    def __getitem__(self, key):
        if key in self:
            val=super().get(key,None)
            if isinstance(val,str):
                if val.startswith('"'):
                    return val[1:-1]
            return val
        
        return None


################
#
################
    def add_child(self,child:FhxObject)->None:

        if child.fhx_type in self:
            l=self[child.fhx_type]
        else:
            l=[]

        l.append(child)

        self[child.fhx_type]=l
        child.parent=self

################
#
################
    def link_children_to_self(self)->None:
        for k,v in self.items():
            if isinstance(v,list):
                for i in v:
                    i.link_children_to_self()
                    i.parent=self
                    i.fhx_type=k
                    
    
################
#
################
    def __repr__(self) -> str:
        if '@NAME' in self:
            return f"{self.fhx_type} [{self['@NAME']}]"
        elif '@TAG' in self:
            return f"{self.fhx_type} [{self['@TAG']}]"
        elif '@ID' in self:
            return f"{self.fhx_type} [{self['@ID']}]"

        return self.fhx_type
    
################
#
################
    def getRoot(self) -> FhxObject:
        """Return the root level FhxObject in a tree.
        Subordinate .parent attributes need to have been updated via .update_child_parent() at root level
        prior to invoking this method."""
        if self.parent is None:
            return self

        if isinstance(self.parent,FhxObject):
            return self.parent.getRoot()
        
        raise ValueError("Error: property .parent is not FhxObject(" + str(type(self.parent)) + ")") 

################
#
################
    def getTop(self) -> FhxObject:
        """Return the top level FhxObject i.e MODULE_CLASS or FUNCTION_BLOCK_DEFINITION,..."""
        if self.parent==None:
            return self

        if self.parent.fhx_type in [None,'','root']:
            return self
        
        elif isinstance(self.parent,FhxObject):
            return self.parent.getTop()
        
        raise ValueError("Error: property .parent is not FhxObject(" + str(type(self.parent)) + ")")

    ################
    #
    ################
    def quotes_on(self):
        """Return true if the FHX string value quotes are on for this object"""
        return self.getTop().get('__quotes_on',False)

    ################
    #   return the first value that match the path query. if the value is a string and quotes are on, the quotes will be removed
    #   
    ################
    def getValue(self, query:str):
        """Return the first value that match the path query. if the value is a string and quotes are on, the quotes will be removed"""
        if '/' in query:
            value=self.xpath(query)
            if len(value)==0:
                return None
        
            value=value[0]
            if isinstance(value,str):
                if value.startswith('"'):
                    return value[1:-1]
        else:
            value=self[query]
            
        return value

    ##############
    ## Method
    ##############  
    def IsEMC(self):
        if self.fhx_type=='MODULE_CLASS':
            if (self.getValue('FBD_ALGORITHM/IS_EQUIPMENT_MODULE') == 'T'):
                return True
            
            if (self.getValue('COMMAND_DRIVEN_ALGORITHM/IS_EQUIPMENT_MODULE') == 'T'):
                return True

        return False    
    
    ##############
    ## Method
    ##############  
    def IsSFC(self):
        if self.fhx_type in ["MODULE_CLASS",
                            "MODULE",
                            "FUNCTION_BLOCK_DEFINITION"]:
            if 'SFC_ALGORITHM' in self:
                return True    
        return False    

     ##############
    ## Method
    ##############  
    def IsFBD(self):
        if self.fhx_type in ["MODULE_CLASS",
                            "MODULE",
                            "FUNCTION_BLOCK_DEFINITION"]:
            if 'FBD_ALGORITHM' in self:
                return True    
        return False    
           
    ################
    #
    ################    
    def getValueString(self)->str:
        value=self.getValue('VALUE')
        if value==None:
            return None
        
        if isinstance(value,FhxObject):
            if 'CV' in value:
                return str(value['CV'])
            elif ('SET' in value) and ('STRING_VALUE' in value):
                return str(value['SET']) + ':' + str(value['STRING_VALUE'])
            elif ('ENUM_SET' in value):
                return 'ENUM_SET -> ' + str(value['ENUM_SET'])
            elif ('EXPRESSION' in value):
                return str(value['EXPRESSION'])
            else: 
                return str(self['VALUE'])
        else:
            return str(self['VALUE'])
################
#
################
    def to_fhx(self)->str:
        """Generate UTF8 text of FHX"""
        quotes_on=self.quotes_on()
        return to_fhx(self,quotes_on)
    
################
#
################
    def xpath(self,path)-> list:
        """Evaluate a query on a nested Python object"""
        return xpath(self,path)

    
################
#
################

    def get_id(self) -> tuple:
        """ returns (Fhx_Type.Tag, id)"""
        if '@NAME'in self:
            return self.fhx_type + '.@NAME',self['@NAME']
        
        if '@TAG'in self:
            return self.fhx_type + '.@TAG', self['@TAG']

        if '@ID'in self:
            return self.fhx_type + '.@ID', self['@ID']

        if '@CLASS'in self:
            return self.fhx_type + '.@CLASS', self['@CLASS']
            
        if '@INDEX'in self:
            return self.fhx_type + '.@INDEX', self['@INDEX']
        
        if self.fhx_type =='TRANSITION_STEP_CONNECTION':
            return self.fhx_type + '.@TRANSITION', self['@TRANSITION']   

        if self.fhx_type =='STEP_TRANSITION_CONNECTION':
            return self.fhx_type + '.@STEP', self['@STEP'] 
        
        # get the first attribute that match
        for a in self:
            if  a != '__fhx_type' and a.startswith('@'):
                return self.fhx_type + '.' + a , self[a]         

        return self.fhx_type + '.' , self.fhx_type

    
################
#
################
    def getPathId(self) -> str:
        """ returns (Fhx_Type.Tag, id)"""
        if '@NAME'in self:
            return f'{{@NAME="{self['@NAME']}"}}'
        
        if '@TAG'in self:
            return f'{{@TAG="{self['@TAG']}"}}'

        return None
        try:
            idx = lst.index(value)
        except ValueError:
            idx = -1

        # get the first attribute that match
        for attribute in self:
            if  attribute != '__fhx_type' and attribute.startswith('@'):
                return self.fhx_type + '{' + attribute +'='+ self[attribute] + '}'
         

        return self.fhx_type 

    
################
#
################
    def my_xpath(self):
        if self.parent==None:            
            return self.getId()

        parent_xpath=self.parent.my_xpath()
        if parent_xpath in [None,'','root']:
            return self.getId()
        else:
            return parent_xpath + '/' + self.getPathId()

################
#
################   
    def get_file_name(self):
        if self.fhx_file==None:
            return self.parent.get_file_name()
        
        return self.fhx_file 


