"""Functions to load FhxObjects from .fhx files"""
import json
import logging
import os
import sys
from .fhx_object import FhxObject
from .fhx_parser import FhxFileParser

logging.basicConfig(
    level=logging.DEBUG,
    format="%(levelname)s - %(message)s"
)
###################
#
##################
def _ignored_type(fhx_type,selective_types=[],ignore_objects=[])->bool:
    if len(selective_types)>0:
       return not (fhx_type in selective_types)
    
    if len(ignore_objects)>0:
        return fhx_type in ignore_objects

    return False

###################
#
##################
def load_single_file(fhx_file,selective_types=[],ignore_objects=[]) -> FhxObject:
    """fhx file name stored at the top level fhx object only"""
    root = FhxObject(fhx_type="root")
    if not os.path.exists(fhx_file):
        logging.error(f'File ({fhx_file}) does not exist')
        sys.exit(1)
    try:
        
        fhxParser=FhxFileParser(fhx_file,1) 
        while (element := fhxParser.nextFhxObject()) is not None:
            if _ignored_type(element.fhx_type,selective_types,ignore_objects):
                continue

            if isinstance(element , FhxObject): 
                    element.fhx_file=fhx_file
                    root.add_child(element)
            else:
                logging.error(f'{str(element)} can only be a a FhxObject')   
    except Exception as e:
        logging.error(f"File ({fhx_file}) not parseable as FHX: {str(e)}")

    return root

###################
#
##################
def add_file(root,fhx_file,path):
    results = load_file(path, fhx_file)
    for fhx_obj in results:
        if fhx_obj is not None:
            root.add_child(fhx_obj)     


###################
#
##################
def load_fhx_dir(path: str, selective_types=[],ignore_objects=[]) -> FhxObject:
    """Load all fhx files from fhx_objects_order.json.  Return root level FhxObject"""

    import_order_file = path + '/fhx_objects_order.json'

    logging.info(f'Reading File ({import_order_file})...')
    if not os.path.exists(import_order_file):
            logging.error(f'File ({import_order_file}) does not exist')
            sys.exit(1)
    try:
        with open(import_order_file, 'r', encoding='utf-8') as order_file:
            fhx_files = json.load(order_file)
    except Exception as e:
        logging.error(f"File ({import_order_file}) not parseable as JSON: {str(e)}")
        sys.exit(1)

    root = FhxObject(fhx_type="root")
    root.path = path
    logging.info(f'Loading FHX files from ({path})...')
    for fhx_type,fhx_files in fhx_files.items():
        if  _ignored_type(fhx_type,selective_types,ignore_objects):
            continue
        if isinstance(fhx_files,list):
            for fhx_file in fhx_files:
                add_file(root,fhx_file.split(',')[0],path)
        elif isinstance(fhx_files,str):
            add_file(root,fhx_files,path)           

    logging.info(f'Loading FHX files from ({path}) completed.')
    return root
    

###################
#
##################
def load_file(path, fhx_file):
    """Read fhx file, generate new FhxObjects. Returns list of FhxObjects or None"""
    f = path + fhx_file
    if not os.path.exists(f):
        logging.error(f"File ({f}) does not exist")
        return None
    else:
        try:
            filename, file_extension = os.path.splitext(f)
            if file_extension == '.fhx':
               return loadfhx_list(f)
            elif file_extension == '.json':
                return loadjson_list(f)           
        except Exception as e:
            logging.error(f"File ({fhx_file}) not parseable as FHX: {str(e)}")


###################
#
##################
def loadfhx_list(fhx_file) -> list:
    """fhx file name stored at the top level fhx object only"""
    root = []
    if not os.path.exists(fhx_file):
        logging.error(f'File ({fhx_file}) does not exist')
        return None
    else:
        try:
            
            fhxParser=FhxFileParser(fhx_file,1) 
            while (element := fhxParser.nextFhxObject()) is not None:

                if isinstance(element , FhxObject): 
                        element.fhx_file=fhx_file
                        root.append(element)
                else:
                    logging.error(f'{str(element)} can only be a a FhxObject')   
        except Exception as e:
            logging.error(f"File ({fhx_file}) not parseable as FHX: {str(e)}")

    return root


################
#
################  
def loadjson_list(json_file: str) -> list:
    """Loads the supplied obj_dict into an FhxObject, as well as any contained objects and lists"""
    with open(json_file, 'r', encoding='utf-8') as content_file:
        fhx_dict=json.load(content_file)  
    out=[]
    if isinstance(fhx_dict,list):
        for item in fhx_dict:
            fhx_type=item['__fhx_type']
            del item['__fhx_type']       
            out.append(FhxObject(item,fhx_type=fhx_type,fhx_file=json_file))            
    else:
        fhx_type=fhx_dict['__fhx_type']
        del fhx_dict['__fhx_type']       
        out.append(FhxObject(fhx_dict,fhx_type=fhx_type,fhx_file=json_file))

    return out