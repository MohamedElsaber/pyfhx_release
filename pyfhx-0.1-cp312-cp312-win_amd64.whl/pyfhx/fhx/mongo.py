#from pymongo import MongoClient
#from bson.codec_options import CodecOptions
import logging
import re
from .fhx_object import FhxObject
from .fhx_parser import FhxFileParser
from .config import elements_config
logging.basicConfig(
    level=logging.DEBUG,
    format="%(levelname)s - %(message)s"
)

fhx_order_collection=elements_config['fhx_order']
##############
## Method
##############     
def __tokenReplace(obj, text:str):
    '''Replaces all {{token}} values in provided text with value from obj, much like Jinja2 tokens are instantiated'''
    out=""
    if '|' in text:
        for  option in text.split("|"):
            out=__tokenReplace_option(obj,option)
            if len(out)>0:# return the first option that contain all resolved tokens
                return out.replace('.','').replace('>','')
    else:
        out= __tokenReplace_option(obj,text)

    if len(out)==0:
        print('Warning: Object of a type (' + obj.fhx_type + ') did not resolve tokens ' + text)
        try:
            print('Object: ' + obj.to_fhx()[:100].replace('\r\n',' '))
        except:
            pass

        return ''

    return out

##############
## Method
##############     
def __tokenReplace_option(obj:FhxObject, text:str):
    tokens = re.findall('({{.+?}})', text)
    for t in tokens:
        temp = t.replace('{{', '').replace('}}', '')
        rep=obj.getValue(temp)
        if isinstance(rep,str):
            if rep=='':
                return ''

            rep = re.sub(r'[\.\|\$\\><\?\:\"\* ]', '', rep)
            text = text.replace(t, rep)
        else:
           return ''        
    return text

##############
## Method
##############  
def __get_Node_info(obj:FhxObject):   
    if obj.fhx_type in elements_config:
        dir_tokens=elements_config[obj.fhx_type]['dir']
        file_tokens=elements_config[obj.fhx_type]['file_name']
        try:
            parent_node=__tokenReplace(obj,dir_tokens)
            if parent_node=='':
                parent_node=elements_config['Xtra'] + '/' + obj.fhx_type

            obj_label=__tokenReplace(obj,file_tokens)
            if obj_label=='':
                obj_label=obj.fhx_type

            if obj.fhx_type in elements_config['AdvancedDefinitions']:
                if parent_node.startswith('/Library/'):
                    parent_node='/Library/Advanced Definitions/' +  parent_node[9:] 

            return parent_node , obj_label
        except Exception as e:              
            raise Exception(f"Uanable to determine node name and parent: {str(e)}")
    else:
        return elements_config['Xtra'] , obj.fhx_type

##############
## Method
##############  
def getmetadata(element:FhxObject,doc_id:str,corpus:str,equipment_module_classes:set):
    deltav_type=''
    dir,label=__get_Node_info(element)
    if element.fhx_type=='MODULE_CLASS':
        if element.IsEMC():
            equipment_module_classes.add(element['@NAME'])
            deltav_type= "EQUIPMENT_MODULE_CLASS"
        else:
            deltav_type=  "CONTROL_MODULE_CLASS"

    elif element.fhx_type=='MODULE_INSTANCE':
        mc=element['@MODULE_CLASS']
        if mc in equipment_module_classes:
            deltav_type= "EQUIPMENT_MODULE_INSTANCE"
        else:
            deltav_type= "CONTROL_MODULE_INSTANCE"

    elif element.fhx_type=='MODULE':
        category=element['@CATEGORY']
        if category =="":
            deltav_type= "MODULE"
        else:
            deltav_type= "MODULE TEMPLATE"

    elif element.fhx_type=='FUNCTION_BLOCK_DEFINITION':
        category=element['@CATEGORY']
        if category =="":
            deltav_type= "EMBEDDED_COMPOSITE"
        else:
            deltav_type= "LINKED_COMPOSITE"

    metadata={'fhx_type':element.fhx_type,
            'doc_id':str(doc_id.inserted_id),
            'dir':dir,
            'label':label,
            'deltav_type':deltav_type,
            'data':"",
            '__corpus':corpus
    }    
    
    return metadata
#############################################
#
#
#############################################
# ─────────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────────
#MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
#DB_NAME   = "DeltaV_OSP5"
def saveMongoDB(client,db_name,fhx_file):   
    #client    = MongoClient(url)
    #client    = MongoClient("mongodb://localhost:27017/")
    # ─────────────────────────────────────────────────────────────────
    # STEP 1 — DROP DATABASE IF EXISTS
    # ─────────────────────────────────────────────────────────────────
    existing_dbs = client.list_database_names()

    if db_name in existing_dbs:
        client.drop_database(db_name)
    db = client[db_name]
    #'fhxtype,doc_id,parent_node,label,type,icon'
    equipment_module_classes=set()
    db[fhx_order_collection].create_index(['fhx_type','doc_id'],unique=True,name='idx_pk')
    db[fhx_order_collection].create_index({"__corpus":"text"},name='idx_text')  
    try:
        fhxParser=FhxFileParser(fhx_file)
        for element in fhxParser:
            if element.fhx_type in elements_config["Ignore"]:
                pass

            ndx=[]
            element.fhx_type=element.fhx_type
            if not(element.fhx_type in db.list_collection_names()):
                if (element.fhx_type in elements_config):
                    ndx=elements_config[element.fhx_type]['index']['unique']
                if len(ndx)>0:
                    db[element.fhx_type].create_index(ndx,unique=True,name='idx_fhx_pk')

            try:
                corpus=element['__corpus']
                del element['__corpus']                 
                doc_id=db[element.fhx_type].insert_one(element)
                metadata=getmetadata(element,str(doc_id.inserted_id),corpus,equipment_module_classes)
                
                db[fhx_order_collection].insert_one(metadata)
            except Exception as e:
                logging.error(f'Error inserting element into MongoDB: {str(e)}')

    except Exception as e:
        logging.error(f'Error creating FhxFileParser for file ({fhx_file}) Error: {str(e)}')
        return

    logging.info(f'FHX File {fhx_file} Saved to MongoDB {db_name}')


#############################################
#
#
#############################################
def loadMongo(
    client,
    database_name:str,
    fhx_types=None,
    codec_options=None
):
    """
    High-performance MongoDB loader with streaming and batching.

    Streams documents in controllable batches, maps them to FhxObject,
    links children, and aggregates them under a root node.

    Parameters
    ----------
    client : pymongo.MongoClient
        MongoDB client instance

    db : str
        Database name

    fhx_types : list | None
        Collection specifications:
        - str
        - (fhx_type, filter, projection)

    codec_options : bson.codec_options.CodecOptions | None
        Optional codec options for MongoDB collections. If not provided,

    Returns
    -------
    FhxObject
    """


    #client = MongoClient(url)
    #codec_options = CodecOptions(document_class=FhxObject)

    root = FhxObject(fhx_type = "root")

    database = client.get_database(database_name, codec_options=codec_options)

    #batch_size=1000
    no_cursor_timeout=True

    # Resolve collections lazily
    if not fhx_types:
        fhx_types = (
            (name, {}, {"_id": 0})
            for name in database.list_collection_names()
        )

    for fhx_type_tuple in fhx_types:
        if isinstance(fhx_type_tuple, tuple):
            if len(fhx_type_tuple)==3:
                fhx_type, col_filter, col_project = fhx_type_tuple
            elif len(fhx_type_tuple)==2:
                fhx_type, col_filter = fhx_type_tuple
                col_project = {"_id": 0}
            elif len(fhx_type_tuple)==1:
                fhx_type = fhx_type_tuple[0]
                col_filter = {}
                col_project = {"_id": 0}
            elif len(fhx_type_tuple)==0:
                logging.error(f'Error: fhx_type_tuple is empty: {str(fhx_type_tuple)}')
                continue    
        else:
            fhx_type = fhx_type_tuple
            col_filter = {}
            col_project = {"_id": 0}

        collection = database.get_collection(
            fhx_type,
            codec_options=codec_options
        )

        cursor = collection.find(
            filter=col_filter,
            projection=col_project,
            no_cursor_timeout=no_cursor_timeout
        )

        try:
            for doc in cursor:
                doc.fhx_type = fhx_type
                doc.link_children_to_self()
                root.add_child(doc)
        finally:
            cursor.close()

    return root
