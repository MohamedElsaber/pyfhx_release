elements_config={
  "ALARM_ANNUNCIATION": {
    "dir": "/System Configuration/Setup/Alarm Preferences/Alarm Priorities",
    "file_name": "{{@UI_NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@UI_NAME"
      ]
    }
  },
  "ATTRIBUTE_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "ATTRIBUTE_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "BATCH_EQUIPMENT_PHASE_CLASS": {
    "dir": "/{{@CATEGORY}}/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "BATCH_EQUIPMENT_PROCESS_CELL": {
    "dir": "/System Configuration/Control Strategies/{{PROCESS_CELL/@PLANT_AREA}}/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "BATCH_EQUIPMENT_PROCESS_CELL_CLASS": {
    "dir": "/{{@CATEGORY}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "BATCH_EQUIPMENT_UNIT_MODULE": {
    "dir": "/System Configuration/Control Strategies/{{UNIT_MODULE/@PLANT_AREA}}/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "BATCH_EQUIPMENT_UNIT_MODULE_CLASS": {
    "dir": "/{{UNIT_MODULE_DEFINITION/@CATEGORY}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "BATCH_RECIPE": {
    "dir": "/System Configuration/{{@CATEGORY}}|/System Configuration/Recipes/{{@TYPE}}S",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "BATCH_SERVER": {
    "dir": "/System Configuration/Physical Network/Control Network",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "CHARM": {
    "dir": "/System Configuration/Physical Network/Control Network/IO Network/{{@CONTROLLER}}/{{@IO_SUBSYSTEM}}",
    "file_name": "CHM{{@CARD_SLOT}}({{CONTROLLER_ASSIGNMENT}})|CHM{{@CARD_SLOT}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@CONTROLLER",
        "@IO_SUBSYSTEM",
        "@CARD_SLOT"
      ]
    }
  },
  "CHARM_IO_SERVER_NODE": {
    "dir": "/System Configuration/Physical Network/Control Network/IO Network/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "CONTROLLER_NODE": {
    "dir": "/System Configuration/Physical Network/Control Network/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "DEFAULT_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "DEFAULT_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "DEVICENET_CARD": {
    "dir": "/System Configuration/Physical Network/Control Network/{{@CONTROLLER}}/{{@IO_SUBSYSTEM}}/C{{@CARD_SLOT}}",
    "file_name": "DEVICENET_CARD",
    "index": {
      "nonunique": [],
      "unique": [
        "@CONTROLLER",
        "@IO_SUBSYSTEM",
        "@CARD_SLOT"
      ]
    }
  },
  "DOMAINS": {
    "dir": "/System Configuration/Physical Network/Control Network",
    "file_name": "DOMAINS",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "ENGINEERING_UNITS": {
    "dir": "/System Configuration/Setup",
    "file_name": "ENGINEERING_UNITS",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "ENUMERATION_SET": {
    "dir": "/System Configuration/Setup/{{CATEGORY}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "FIELD_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "FIELD_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "FIELDBUS_IO_CARD": {
    "dir": "/System Configuration/Physical Network/Control Network/{{@CONTROLLER}}/{{@IO_SUBSYSTEM}}/C{{@CARD_SLOT}}",
    "file_name": "FIELDBUS_IO_CARD",
    "index": {
      "nonunique": [],
      "unique": [
        "@CONTROLLER",
        "@IO_SUBSYSTEM",
        "@CARD_SLOT"
      ]
    }
  },
  "FUNCTION_BLOCK_DEFINITION": {
    "dir": "/{{@CATEGORY}}|/Xtra DeltaV Definitions/FUNCTION_BLOCK_DEFINITION",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "GROUP": {
    "dir": "/System Configuration/Setup/Security/groups",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "Ignore": [
    "NODE_INSTALLATION_RECORDS",
    "SNAPSHOT_VCR"
  ],
  "INTEGRATION_NODE": {
    "dir": "/System Configuration/Physical Network/Control Network",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "LOCK": {
    "dir": "/System Configuration/Setup/Security/locks",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "MODULE": {
    "dir": "/System Configuration/Control Strategies/{{@PLANT_AREA}}/{{@TAG}}|/{{@CATEGORY}}/{{@TAG}}",
    "file_name": "{{@TAG}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@TAG"
      ]
    }
  },
  "MODULE_CLASS": {
    "dir": "/{{@CATEGORY}}/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "MODULE_INSTANCE": {
    "dir": "/System Configuration/Control Strategies/{{@PLANT_AREA}}|/{{@CATEGORY}}",
    "file_name": "{{@TAG}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@TAG"
      ]
    }
  },
  "OPERATION_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "OPERATION_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "OPERATOR_NODE": {
    "dir": "/System Configuration/Physical Network/Control Network",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "PK_CONTROLLER_NODE": {
    "dir": "/System Configuration/Physical Network/Control Network/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "PLANT_AREA": {
    "dir": "/System Configuration/Control Strategies/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "PROCESS_CELL": {
    "dir": "/System Configuration/Control Strategies/{{@PLANT_AREA}}/{{@NAME}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "PROFESSIONAL_PLUS_NODE": {
    "dir": "/System Configuration/Physical Network/Control Network",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "PROFIBUS_CARD": {
    "dir": "/System Configuration/Physical Network/Control Network/{{@CONTROLLER}}/{{@IO_SUBSYSTEM}}",
    "file_name": "C{{@CARD_SLOT}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@CONTROLLER",
        "@IO_SUBSYSTEM",
        "@CARD_SLOT"
      ]
    }
  },
  "PROFIBUS_DEVICE": {
    "dir": "/System Configuration/Physical Network/Control Network/{{PORT_ASSIGNMENT/PATH}}",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "SERIAL_IO_CARD": {
    "dir": "/System Configuration/Physical Network/Control Network/{{@CONTROLLER}}/{{@IO_SUBSYSTEM}}/C{{@CARD_SLOT}}",
    "file_name": "SERIAL_IO_CARD",
    "index": {
      "nonunique": [],
      "unique": [
        "@CONTROLLER",
        "@IO_SUBSYSTEM",
        "@CARD_SLOT"
      ]
    }
  },
  "SIF_FIELD_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "SIF_FIELD_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "SIF_FUNCTION_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "SIF_FUNCTION_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "SIF_MODULE": {
    "dir": "/{{@CATEGORY}}",
    "file_name": "{{@TAG}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@TAG"
      ]
    }
  },
  "SIF_PARAMETER_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "SIF_PARAMETER_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "SIMPLE_IO_CARD": {
    "dir": "/System Configuration/Physical Network/Control Network/{{@CONTROLLER}}/{{@IO_SUBSYSTEM}}",
    "file_name": "C{{@CARD_SLOT}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@CONTROLLER",
        "@IO_SUBSYSTEM",
        "@CARD_SLOT"
      ]
    }
  },
  "SIS_DEFAULT_SECURITY": {
    "dir": "/System Configuration/Setup/Security",
    "file_name": "SIS_DEFAULT_SECURITY",
    "index": {
      "nonunique": [],
      "unique": []
    }
  },
  "SIS_ENUMERATION_SET": {
    "dir": "/System Configuration/Setup/Named Sets",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "SIS_LOCK": {
    "dir": "/System Configuration/Setup/Security/sis_locks",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "SIS_SYSTEM_ALARM": {
    "dir": "/System Configuration/Setup/Alarm Preferences/Alarm Types/SIS System Alarm",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "SIS_SYSTEM_ENUMERATION_SET": {
    "dir": "/System Configuration/Setup/Named Sets",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "SYSTEM_ALARM": {
    "dir": "/System Configuration/Setup/Alarm Preferences/Alarm Types/System Alarm",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "SYSTEM_ENUMERATION_SET": {
    "dir": "/System Configuration/Setup/Named Sets",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "USER": {
    "dir": "/System Configuration/Setup/Security/users",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "USER_ALARM": {
    "dir": "/System Configuration/Setup/Alarm Preferences/Alarm Types/User Alarm",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "USER_ALARM_INDEXED": {
    "dir": "/System Configuration/Setup/Alarm Preferences/Alarm Types/User Alarm Indexed",
    "file_name": "{{@NAME}}",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "SFC": {
    "dir": "",
    "file_name": "",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "FBD": {
    "dir": "",
    "file_name": "",
    "index": {
      "nonunique": [],
      "unique": [
        "@NAME"
      ]
    }
  },
  "AdvancedDefinitions": [
    "BATCH_EQUIPMENT_PROCESS_CELL_CLASS",
    "BATCH_EQUIPMENT_PHASE_CLASS",
    "MODULE_CLASS",
    "BATCH_EQUIPMENT_UNIT_MODULE_CLASS"
  ],
   "logicFhxTypes":[
    "MODULE_CLASS",
    "MODULE_INSTANCE",
    "MODULE",
    "FUNCTION_BLOCK_DEFINITION",
    "BATCH_EQUIPMENT_PHASE_CLASS"
    ], 
    "fhx_order_collection":"__fhx_order",
  "Xtra": "/Xtra DeltaV Definitions"
}
