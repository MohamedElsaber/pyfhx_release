# License System Integration Guide

## Quick Start

### For End Users

1. **Get Your Hardware ID**:
   ```bash
   python scripts/hardware_id.py
   ```
   Share this ID with the license provider.

2. **Receive License File**:
   You'll receive a file like `license.json` from the software provider.

3. **Use the License**:
   ```python
   import pyfhx_c
   from scripts.hardware_id import generate_hardware_id
   
   # Get your hardware ID
   hw_info = generate_hardware_id()
   hw_id = hw_info['hardware_id']
   
   # Load and validate license
   pyfhx_c.load_license('path/to/your/license.json', hw_id)
   pyfhx_c.validate_license()
   
   # Now use pyfhx_c normally
   ```

### For License Providers/Developers

See [pyfhx_c/license/README.md](../pyfhx_c/license/README.md) for complete setup instructions.

## Build System Integration

### CMakeLists.txt Configuration

Add OpenSSL and nlohmann_json to your CMakeLists.txt:

```cmake
# Find OpenSSL
find_package(OpenSSL 1.1.1 REQUIRED)

# Find or download nlohmann_json
find_package(nlohmann_json 3.10 QUIET)
if(NOT nlohmann_json_FOUND)
    include(FetchContent)
    FetchContent_Declare(nlohmann_json
        URL https://github.com/nlohmann/json/releases/download/v3.11.2/json.tar.xz)
    FetchContent_MakeAvailable(nlohmann_json)
endif()

# Add license manager to your extension
target_sources(pyfhx_c PRIVATE
    pyfhx_c/license/lic_mngr.cpp
)

target_link_libraries(pyfhx_c PRIVATE
    OpenSSL::Crypto
    nlohmann_json::nlohmann_json
)

target_include_directories(pyfhx_c PRIVATE
    pyfhx_c/license
    ${OPENSSL_INCLUDE_DIR}
)
```

### Python Package Dependencies

Update `pyproject.toml`:

```toml
[build-system]
requires = [
    "scikit-build-core",
    "cryptography>=41.0.0",
]

[project]
dependencies = [
    "cryptography>=41.0.0",
]

[project.optional-dependencies]
license-tools = [
    "cryptography>=41.0.0",
]
```

## Module Integration

### Adding License Method to Python Wrapper

In your Python C extension wrapper (e.g., `pyfhx_c.cpp`):

```cpp
#include "license/lic_mngr.h"

/* Add to method definitions */
static PyMethodDef pyfhx_c_methods[] = {
    // ... existing methods ...
    
    {"load_license", (PyCFunction)py_load_license, 
     METH_VARARGS | METH_KEYWORDS, 
     "Load and validate license file"},
    
    {"validate_license", (PyCFunction)py_validate_license, 
     METH_VARARGS, 
     "Validate the current license"},
    
    {"get_license_info", (PyCFunction)py_get_license_info, 
     METH_VARARGS, 
     "Get information about current license"},
    
    {NULL, NULL, 0, NULL}
};

/* In module initialization */
PyInit_pyfhx_c(void) {
    // ... existing init code ...
    
    // Initialize license manager
    if (!license_manager_init()) {
        PyErr_SetString(PyExc_ValueError, 
                       "Failed to initialize license manager");
        return NULL;
    }
    
    // ... rest of init ...
}
```

## Security Checklist

- [ ] Generate RSA-4096 key pair on secure server
- [ ] Store private key securely (not in git/backup)
- [ ] Embed public key in extension source
- [ ] Rebuild extension with public key
- [ ] Never distribute private key
- [ ] Back up private key in secure location
- [ ] Test license generation and validation
- [ ] Document license key rotation procedure
- [ ] Enable OpenSSL in CI/CD builds

## Testing

### Unit Test Example

```python
import pytest
from pathlib import Path
from scripts.generate_license import LicenseGenerator
from scripts.hardware_id import generate_hardware_id
import pyfhx_c


class TestLicense:
    @pytest.fixture
    def test_keys(self, tmp_path):
        """Generate test keys."""
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.backends import default_backend
        
        # Generate test key pair
        private_key = rsa.generate_private_key(65537, 4096, default_backend())
        
        # Save private key
        priv_path = tmp_path / "private.pem"
        priv_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        priv_path.write_bytes(priv_pem)
        
        return str(priv_path)
    
    def test_license_generation(self, test_keys, tmp_path):
        """Test license generation."""
        gen = LicenseGenerator(test_keys)
        
        license_file = tmp_path / "test_license.json"
        hw_id = "test_hardware_id_12345"
        
        gen.generate_license(
            hardware_id=hw_id,
            days_valid=365,
            output_file=str(license_file)
        )
        
        assert license_file.exists()
        
        # Verify JSON structure
        import json
        license_data = json.loads(license_file.read_text())
        assert license_data['hardware_id'] == hw_id
        assert 'signature' in license_data
        assert 'expiry_date' in license_data
    
    def test_license_validation(self, tmp_path):
        """Test license loading and validation."""
        hw_info = generate_hardware_id()
        hw_id = hw_info['hardware_id']
        
        # Create test license file (using actual key)
        # ... license generation code ...
        
        # Load and validate
        pyfhx_c.load_license('test_license.json', hw_id)
        assert pyfhx_c.validate_license() is True
```

## Troubleshooting Build Issues

### OpenSSL Not Found

On Ubuntu/Debian:
```bash
sudo apt-get install libssl-dev libcrypto++-dev
```

On macOS:
```bash
brew install openssl
# Add to CMake:
# -DOPENSSL_DIR=/usr/local/opt/openssl
```

On Windows:
```bash
# Use vcpkg:
vcpkg install openssl:x64-windows
# Or download from https://slproweb.com/products/Win32OpenSSL.html
```

### nlohmann_json Not Found

```bash
# Option 1: Install via package manager
sudo apt-get install nlohmann-json3-dev  # Ubuntu/Debian
brew install nlohmann-json                 # macOS

# Option 2: Add to CMakeLists.txt
# FetchContent will automatically download it during build
```

## Performance Notes

- License loading and validation is fast (~1-2ms)
- Signature verification takes ~5-10ms (RSA-4096 operations)
- License is verified once at module initialization
- Can optionally cache validation result during runtime

## Compliance

The license system provides:

- **GDPR Compliance**: No personal data stored (only device identifiers)
- **Secure**: RSA-4096 encryption, SHA-256 hashing
- **Offline Support**: License validation works offline
- **Audit Trail**: License file contains generation timestamp
- **License Tied to Device**: Cannot be transferred between machines

---

For more details, see [pyfhx_c/license/README.md](../pyfhx_c/license/README.md)
